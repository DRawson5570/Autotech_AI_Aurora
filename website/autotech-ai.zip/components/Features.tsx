import React from 'react';
import { Icons } from './Icons';
import { FeatureItem } from '../types';

const features: FeatureItem[] = [
  {
    title: 'Instant Specifications',
    description: 'Get fluid capacities, torque specs, and gap settings instantly without flipping through pages.',
    icon: <Icons.Zap className="w-6 h-6" />,
  },
  {
    title: 'Wiring Diagrams',
    description: 'Retrieve pinpoint accurate wiring schematics for virtually any make and model year.',
    icon: <Icons.Cpu className="w-6 h-6" />,
  },
  {
    title: 'DTC Analysis',
    description: 'Input diagnostic trouble codes and get verified fixes, probable causes, and testing procedures.',
    icon: <Icons.Search className="w-6 h-6" />,
  },
  {
    title: 'Component Locations',
    description: 'Stop hunting. Get precise locations and removal instructions for buried components.',
    icon: <Icons.Search className="w-6 h-6" />,
  },
  {
    title: 'Labor Times',
    description: 'Quote accurately with integrated labor time standards directly in the chat.',
    icon: <Icons.Clock className="w-6 h-6" />,
  },
  {
    title: 'TSB Lookup',
    description: 'Automatically checks for relevant Technical Service Bulletins for every vehicle query.',
    icon: <Icons.FileText className="w-6 h-6" />,
  },
];

export const Features: React.FC = () => {
  return (
    <section id="features" className="py-24 bg-slate-900 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h2 className="text-base text-brand-blue font-semibold tracking-wide uppercase">Capabilities</h2>
          <p className="mt-2 text-3xl leading-8 font-extrabold tracking-tight text-white sm:text-4xl">
            Everything you need to finish the job
          </p>
          <p className="mt-4 max-w-2xl text-xl text-slate-400 mx-auto">
            Autotech AI replaces the clutter of multiple tabs and physical manuals with a single, intelligent interface.
          </p>
        </div>

        <div className="mt-20">
          <div className="grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-3">
            {features.map((feature, index) => (
              <div key={index} className="pt-6">
                <div className="flow-root bg-slate-950 rounded-2xl px-6 pb-8 border border-slate-800 hover:border-brand-blue/50 transition-colors h-full group">
                  <div className="-mt-6">
                    <div>
                      <span className="inline-flex items-center justify-center p-3 bg-gradient-to-br from-brand-blue to-blue-600 rounded-md shadow-lg transform group-hover:scale-110 transition-transform duration-300">
                        <div className="text-white">
                            {feature.icon}
                        </div>
                      </span>
                    </div>
                    <h3 className="mt-8 text-lg font-medium text-white tracking-tight">{feature.title}</h3>
                    <p className="mt-5 text-base text-slate-400 leading-relaxed">
                      {feature.description}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};